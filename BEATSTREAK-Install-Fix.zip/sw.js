'use strict';
const CACHE = 'beatstreak-shortcut-shell-v1';
const APP = '/Ten-to-the-Top-Black-Orange.html';
const ASSETS = ['/', '/manifest.webmanifest', '/beatstreak-192.png', '/beatstreak-512.png'];
const ALLOWED = new Set([...ASSETS, APP]);
async function checkedResponse(path) {
  const response = await fetch(new Request(path, {cache:'reload', credentials:'same-origin', redirect:'error'}));
  if (!response.ok || response.type === 'opaque') throw new Error('App file unavailable: ' + path);
  if (path === '/') {
    const html = await response.clone().text();
    if (!html.includes('BEATSTREAK') || !html.includes('id="score"')) throw new Error('The app is behind a login or is not available at this address.');
  }
  if (path.endsWith('.png') && !response.headers.get('content-type')?.startsWith('image/')) throw new Error('Icon unavailable: ' + path);
  if (path.endsWith('.webmanifest')) {
    const manifest = await response.clone().json();
    if (manifest.short_name !== 'BEATSTREAK') throw new Error('Manifest unavailable');
  }
  return response;
}
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const responses = await Promise.all(ASSETS.map(checkedResponse));
    const cache = await caches.open(CACHE);
    await Promise.all(ASSETS.map((path,i) => cache.put(path,responses[i])));
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key.startsWith('beatstreak-shortcut-shell-') && key !== CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || !ALLOWED.has(url.pathname)) return;
  event.respondWith((async () => {
    try {
      // Keep online responses fresh. Only the validated application shell is stored.
      const response = await fetch(request);
      if (!response.ok) throw new Error('App unavailable');
      return response;
    } catch {
      const cache = await caches.open(CACHE);
      const cached = await cache.match(url.pathname) || (request.mode === 'navigate' ? await cache.match('/') : null);
      return cached || Response.error();
    }
  })());
});
